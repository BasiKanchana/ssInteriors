 <!--Start Registration form -->
 <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <form class="index-form">
        <h3 class="text-danger">Registration </h3>

        <label class="index-label" for="name">Name</label>
        <input class="index-input" type="text" placeholder="Enter Your Name" id="name">

        <label class="index-label" for="username">Email Id</label>
        <input class="index-input" type="email" placeholder="Enter Your mail" id="email">


        <label class="index-label" for="tel">Phone No</label>
        <input class="index-input" type="tel" placeholder="Enter Your Number" id="tel">

        <button class="my-2 submit-btn">Submit</button>

    </form>
    <!-- End Registration form -->